# CATATANKU versi Web — Panduan Deploy

Versi web ini sudah memakai konfigurasi Firebase proyek **catatanku-8e11c**.
Setelah dideploy, aplikasi bisa dibuka di browser HP lalu **dipasang ke layar
utama** sehingga tampil seperti aplikasi biasa (ikon CATATANKU, layar penuh,
tanpa bilah alamat).

Data & enkripsinya **sama persis** dengan versi APK (Flutter). Jika kelak Anda
membuat APK dengan proyek Firebase yang sama, akun, PIN, dan catatannya tetap
berlaku di keduanya.

```
catatanku-web/
├── public/              ← isi situs (ini yang di-deploy)
│   ├── index.html       tampilan
│   ├── app.js           logika aplikasi + konfigurasi Firebase Anda
│   ├── kripto.js        AES-256-GCM & PBKDF2 (Web Crypto)
│   ├── sw.js            agar aplikasi bisa dibuka saat offline
│   ├── manifest.webmanifest, icons/
├── firebase.json        pengaturan Firebase Hosting + aturan Firestore
├── .firebaserc          menunjuk ke proyek catatanku-8e11c
└── firestore.rules      aturan keamanan database
```

---

## Langkah 1 — Siapkan Firebase Console (wajib, sekali saja)

Buka https://console.firebase.google.com → proyek **catatanku**.

1. **Authentication** → *Get started* → tab *Sign-in method* →
   **Email/Password** → aktifkan → *Save*.
2. **Firestore Database** → *Create database* → lokasi
   **asia-southeast2 (Jakarta)** → *Start in production mode*.
3. Firestore → tab **Rules** → hapus isinya → tempel seluruh isi
   `firestore.rules` → **Publish**.
   (Jika memakai Cara A di bawah, aturan ini juga ikut terpasang otomatis.)

---

## Langkah 2 — Deploy

### Cara A: Firebase Hosting (perlu komputer)

Firebase Hosting **tidak menyediakan tombol unggah di Console**; deploy harus
lewat Firebase CLI.

1. Pasang Node.js: https://nodejs.org (versi LTS).
2. Buka terminal/Command Prompt di folder `catatanku-web`, lalu:

   ```bash
   npm install -g firebase-tools
   firebase login
   firebase deploy --only hosting,firestore:rules
   ```

3. Selesai. Aplikasi dapat dibuka di:

   - **https://catatanku-8e11c.web.app**
   - https://catatanku-8e11c.firebaseapp.com

Untuk memperbarui aplikasi nanti, cukup ulangi `firebase deploy`.

### Cara B: GitHub Pages (bisa dari HP saja, gratis)

1. Buat akun di https://github.com → **New repository** → nama mis.
   `catatanku` → *Public* → *Create*.
2. Klik **uploading an existing file** → unggah **isi folder `public/`**
   (index.html, app.js, kripto.js, sw.js, manifest.webmanifest, dan folder
   icons) → *Commit changes*.
3. **Settings → Pages** → *Source*: **Deploy from a branch** → Branch: `main`,
   folder `/ (root)` → *Save*. Tunggu 1–2 menit.
4. Alamat aplikasi: `https://NAMAPENGGUNA.github.io/catatanku/`
5. Di Firebase Console → **Authentication → Settings → Authorized domains** →
   *Add domain* → `NAMAPENGGUNA.github.io`.

Pada Cara B, aturan Firestore dipasang manual (Langkah 1 nomor 3).

---

## Langkah 3 — Pasang di HP seperti aplikasi

1. Buka alamat aplikasi di **Chrome** (Android).
2. Menu ⋮ → **Tambahkan ke layar utama** / **Instal aplikasi** → *Instal*.
3. Ikon **CATATANKU** muncul di layar utama; buka dari sana.

(iPhone: buka di Safari → tombol Bagikan → *Tambahkan ke Layar Utama*.)

---

## Cara memakai

1. **Pertama kali**: *Belum punya akun? Daftar* → isi email & kata sandi →
   buat PIN 6 digit → ulangi PIN → **catat KODE PEMULIHAN** (tampil sekali) →
   centang → *LANJUTKAN*.
2. **Berikutnya**: buka aplikasi → masukkan PIN → daftar catatan.
3. **+** untuk menambah; ketuk judul untuk membaca, lalu **EDIT / HAPUS / KEMBALI**.
4. Ikon roda gigi: **Ganti PIN**, **Informasi aplikasi**, **Keluar aplikasi**.
5. **Lupa PIN?** di halaman PIN → masukkan kode pemulihan → buat PIN baru.

Aplikasi meminta PIN lagi setiap kali dibuka ulang, atau setelah ditinggal
lebih dari 60 detik.

---

## Keamanan

- Judul & isi catatan dienkripsi **AES-256-GCM di HP** sebelum dikirim;
  server Firebase hanya menyimpan data acak.
- PIN **tidak disimpan** dalam bentuk apa pun. Kunci diturunkan dengan
  **PBKDF2-HMAC-SHA256** (150.000 iterasi, salt acak per akun).
- Aturan Firestore: tiap akun hanya dapat mengakses datanya sendiri.
- 5 kali PIN salah → dikunci 30 detik, berlipat ganda hingga maks. 15 menit.
- `apiKey` di `app.js` **bukan rahasia**. Ini memang pengenal publik proyek
  Firebase; keamanan data dijaga oleh login, aturan Firestore, dan enkripsi.
- Jika **PIN lupa dan kode pemulihan hilang**, catatan tidak dapat dibuka oleh
  siapa pun. Gunakan juga kata sandi akun yang kuat.

---

## Masalah umum

| Masalah | Solusi |
|---|---|
| “Login email belum diaktifkan” | Langkah 1 nomor 1 |
| “Akses ditolak oleh server…” setelah login | Database belum dibuat / aturan belum di-*Publish* (Langkah 1) |
| “Domain ini belum diizinkan” | Tambahkan domain di *Authorized domains* (Cara B langkah 5) |
| Tampilan lama setelah update | Tutup aplikasi sepenuhnya lalu buka lagi (sekali–dua kali) |
| `firebase: command not found` | Tutup dan buka ulang terminal setelah `npm install -g firebase-tools` |
